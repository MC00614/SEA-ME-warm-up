#include "car.h"

Car::Car()
{
    x_location = 0;
    y_location = 0;
}
