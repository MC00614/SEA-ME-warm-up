#ifndef CAR_H
#define CAR_H


class Car
{
public:
    Car();
    int x_location;
    int y_location;
};

#endif // CAR_H
